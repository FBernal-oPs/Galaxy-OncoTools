---
layout: default
title: Legitimate Interest Analyses
---

We based our LIAs off of the [checklist provided by the ICO](https://ico.org.uk/for-organisations/guide-to-the-general-data-protection-regulation-gdpr/lawful-basis-for-processing/legitimate-interests/)

- [Galactic Radio Telescope](grt.html)
